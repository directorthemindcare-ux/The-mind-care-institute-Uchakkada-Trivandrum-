-- Mind Care Institute secure database starter
create type public.app_role as enum ('parent','therapist','admin');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role public.app_role not null default 'parent',
  phone text,
  created_at timestamptz not null default now()
);

create table public.clients (
  id uuid primary key default gen_random_uuid(),
  client_code text unique not null,
  full_name text not null,
  date_of_birth date,
  guardian_name text,
  guardian_user_id uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.staff_clients (
  staff_id uuid references public.profiles(id) on delete cascade,
  client_id uuid references public.clients(id) on delete cascade,
  primary key (staff_id, client_id)
);

create table public.appointments (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  therapist_id uuid references public.profiles(id),
  starts_at timestamptz not null,
  service text not null,
  status text not null default 'requested',
  notes text,
  created_at timestamptz not null default now()
);

create table public.session_notes (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  therapist_id uuid not null references public.profiles(id),
  session_date date not null default current_date,
  service text not null,
  note text not null,
  created_at timestamptz not null default now()
);

create table public.consents (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  consent_type text not null,
  granted boolean not null default false,
  granted_by uuid references public.profiles(id),
  granted_at timestamptz not null default now()
);

create or replace function public.my_role() returns public.app_role
language sql stable security definer set search_path = public
as $$ select role from public.profiles where id = auth.uid() $$;

alter table public.profiles enable row level security;
alter table public.clients enable row level security;
alter table public.staff_clients enable row level security;
alter table public.appointments enable row level security;
alter table public.session_notes enable row level security;
alter table public.consents enable row level security;

create policy "profiles self or admin" on public.profiles for select using (id = auth.uid() or public.my_role() = 'admin');
create policy "profiles self update" on public.profiles for update using (id = auth.uid());

create policy "clients admin" on public.clients for all using (public.my_role() = 'admin') with check (public.my_role() = 'admin');
create policy "clients parent" on public.clients for select using (guardian_user_id = auth.uid());
create policy "clients therapist" on public.clients for select using (exists(select 1 from public.staff_clients sc where sc.client_id = id and sc.staff_id = auth.uid()));

create policy "staff_clients admin" on public.staff_clients for all using (public.my_role() = 'admin') with check (public.my_role() = 'admin');
create policy "staff_clients therapist self" on public.staff_clients for select using (staff_id = auth.uid());

create policy "appointments admin" on public.appointments for all using (public.my_role() = 'admin') with check (public.my_role() = 'admin');
create policy "appointments parent" on public.appointments for select using (exists(select 1 from public.clients c where c.id = client_id and c.guardian_user_id = auth.uid()));
create policy "appointments therapist" on public.appointments for select using (therapist_id = auth.uid());
create policy "appointments therapist update" on public.appointments for update using (therapist_id = auth.uid());
create policy "appointments parent insert" on public.appointments for insert with check (exists(select 1 from public.clients c where c.id = client_id and c.guardian_user_id = auth.uid()));

create policy "notes admin" on public.session_notes for all using (public.my_role() = 'admin') with check (public.my_role() = 'admin');
create policy "notes therapist" on public.session_notes for all using (therapist_id = auth.uid()) with check (therapist_id = auth.uid());
create policy "notes parent read" on public.session_notes for select using (exists(select 1 from public.clients c where c.id = client_id and c.guardian_user_id = auth.uid()));

create policy "consents admin" on public.consents for all using (public.my_role() = 'admin') with check (public.my_role() = 'admin');
create policy "consents parent" on public.consents for select using (exists(select 1 from public.clients c where c.id = client_id and c.guardian_user_id = auth.uid()));
create policy "consents parent grant" on public.consents for insert with check (exists(select 1 from public.clients c where c.id = client_id and c.guardian_user_id = auth.uid()) and granted_by = auth.uid());

-- After creating the first authenticated admin user, replace USER_UUID below with its auth.users UUID:
-- update public.profiles set role='admin' where id='USER_UUID';
